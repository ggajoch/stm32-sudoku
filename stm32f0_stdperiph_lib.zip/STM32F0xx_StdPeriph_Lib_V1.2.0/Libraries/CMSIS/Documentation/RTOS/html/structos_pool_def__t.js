var structos_pool_def__t =
[
    [ "item_sz", "structos_pool_def__t.html#a4c2a0c691de3365c00ecd22d8102811f", null ],
    [ "pool", "structos_pool_def__t.html#a269c3935f8bc66db70bccdd02cb05e3c", null ],
    [ "pool_sz", "structos_pool_def__t.html#ac112e786b2a234e0e45cb5bdbee53763", null ]
];