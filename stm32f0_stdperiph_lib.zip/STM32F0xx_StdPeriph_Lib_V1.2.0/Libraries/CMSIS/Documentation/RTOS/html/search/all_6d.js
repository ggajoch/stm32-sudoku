var searchData=
[
  ['mail_20queue_20management',['Mail Queue Management',['../group___c_m_s_i_s___r_t_o_s___mail.html',1,'']]],
  ['message_20queue_20management',['Message Queue Management',['../group___c_m_s_i_s___r_t_o_s___message.html',1,'']]],
  ['mutex_20management',['Mutex Management',['../group___c_m_s_i_s___r_t_o_s___mutex_mgmt.html',1,'']]],
  ['memory_20pool_20management',['Memory Pool Management',['../group___c_m_s_i_s___r_t_o_s___pool_mgmt.html',1,'']]],
  ['mail_5fid',['mail_id',['../group___c_m_s_i_s___r_t_o_s___definitions.html#ac86175a4b1706bee596f3018322df26e',1,'osEvent']]],
  ['message_5fid',['message_id',['../group___c_m_s_i_s___r_t_o_s___definitions.html#af394cbe21dde7377974e63af38cd87b0',1,'osEvent']]]
];
